package com.example.demo.model;

public enum Grade {
  STAR1, STAR2, STAR3, STAR4, STAR5
}
