package com.example.ch17_database

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.content.ContextCompat.startActivity
import androidx.recyclerview.widget.RecyclerView
import com.pgm.springconn.DetailActivity
import com.pgm.springconn.MainActivity
import com.pgm.springconn.UserModel
import com.pgm.springconn.databinding.ItemBinding

class MyViewHolder(val binding: ItemBinding): RecyclerView.ViewHolder(binding.root)


class MyAdapter(val context: Context,val datas: List<UserModel>?): RecyclerView.Adapter<RecyclerView.ViewHolder>() {


    override fun getItemCount(): Int{
        return datas?.size ?: 0
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder
        = MyViewHolder(ItemBinding.inflate(LayoutInflater.from(parent.context), parent, false))



    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val binding=(holder as MyViewHolder).binding
        val user=datas?.get(position)
        binding.textView.text= user?.username

        binding.textView.setOnClickListener {
            val intent=Intent(context, DetailActivity::class.java)
            Toast.makeText(context,"id:${user?.id}",Toast.LENGTH_SHORT).show()
            intent.putExtra("id",user?.id)
            context.startActivity(intent)
        }

    }


}
