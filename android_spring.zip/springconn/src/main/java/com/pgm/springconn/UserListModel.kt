package com.pgm.springconn

data class UserListModel(
    var users:List<UserModel>?=null
)