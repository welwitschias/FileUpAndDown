package com.pgm.springconn

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.pgm.springconn.databinding.ActivityDetailBinding
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class DetailActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding=ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val networkService = (applicationContext as MyApplication).networkService
        val id=intent.getLongExtra("id",0)
        binding.textView3.text="id:${id}"
        val userModelCall=networkService.doGetUser(id)
        userModelCall.enqueue(object:Callback<UserModel>{
            override fun onResponse(call: Call<UserModel>, response: Response<UserModel>) {
                val userModel=response.body()
                binding.textView3.text="${userModel?.id}, ${userModel?.username}, ${userModel?.roles}\n"
            }

            override fun onFailure(call: Call<UserModel>, t: Throwable) {
                call.cancel()
            }

        })

    }
}