package com.pgm.android_servier;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AndroidServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
