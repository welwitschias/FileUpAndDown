package com.baemin.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.baemin.dto.FoodDto;
import com.baemin.dto.FoodOptionDto;
import com.baemin.dto.StoreDto;

@Mapper
public interface StoreMapper {

	public List<StoreDto> storeList(int category, int address);

	public StoreDto storeDetail(long storeId);

	public List<FoodDto> foodList(long storeId);
	
	public List<FoodOptionDto> foodOption(long foodId);
	
}