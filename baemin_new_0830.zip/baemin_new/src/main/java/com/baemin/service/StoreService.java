package com.baemin.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.baemin.dao.StoreMapper;
import com.baemin.dto.FoodDto;
import com.baemin.dto.FoodOptionDto;
import com.baemin.dto.StoreDetailDto;
import com.baemin.dto.StoreDto;

@Service
public class StoreService {

	@Autowired
	StoreMapper storeMapper;

	@Transactional
	public List<StoreDto> storeList(int category, int address) {
		return storeMapper.storeList(category, address);
	}

	@Transactional
	public StoreDetailDto storeDetail(long storeId) {
		StoreDto storeDto = storeMapper.storeDetail(storeId);
		List<FoodDto> foodList = storeMapper.foodList(storeId);
		return new StoreDetailDto(storeDto, foodList);
	}

	@Transactional
	public List<FoodOptionDto> foodOption(long foodId) {
		return storeMapper.foodOption(foodId);
	}
	
}