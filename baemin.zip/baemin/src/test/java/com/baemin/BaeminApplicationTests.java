package com.baemin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BaeminApplicationTests {

	@Test
	void contextLoads() {
	}

}
