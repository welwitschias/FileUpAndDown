package com.baemin.dao;

public interface AdminDAO {

	int pointUpdate(long userId, String info, int point);

}
