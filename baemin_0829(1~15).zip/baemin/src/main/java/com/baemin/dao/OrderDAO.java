package com.baemin.dao;

import java.util.List;

import com.baemin.dto.OrderDetail;

public interface OrderDAO {
	// 주문 정보 입력
	void order(OrderInfo info);

	// 주문 상세정보 입력
	void orderDetail(OrderDetail[] detail, long userId);

	@Override
	public List<OrderList> orderList(long userId) {
		return orderDAO.orderList(userId);
	}

}