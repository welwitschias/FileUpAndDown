package com.baemin.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.baemin.dto.OrderDetail;

public class OrderDAOImp implements OrderDAO {

	@Override
	public void order(OrderInfo info) {
		sql.insert("order.order", info);
	}

	@Override
	public void orderDetail(OrderDetail[] detail, long userId) {
		Map<String, Object> map = new HashMap<>();
		map.put("userId", userId);
		map.put("detail", detail);
		sql.insert("order.orderDetail", map);
	}

	@Override
	public List<OrderList> orderList(long userId) {
		return sql.selectList("order.orderList", userId);
	}

}
