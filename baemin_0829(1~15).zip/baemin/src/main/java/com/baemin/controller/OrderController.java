package com.baemin.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.baemin.dto.Cart;
import com.baemin.login.LoginService;
import com.baemin.util.FoodInfoFromJson;

public class OrderController {
	
	@GetMapping("/orderList")
	public String orderList(@AuthenticationPrincipal LoginService user, Model model) {
		if (user == null) {
			System.out.println("비로그인");
		} else {
			System.out.println("로그인");
			long userId = user.getUser().getId();

			List<OrderList> orderList = orderService.orderList(userId);

			if (orderList.size() == 0) {
				return "order/orderList";
			}

			List<List<Cart>> cartList = new ArrayList<>();

			for (int i = 0; i < orderList.size(); i++) {
				cartList.add(FoodInfoFromJson.foodInfoFromJson(orderList.get(i).getFoodInfo()));
			}

			model.addAttribute("user", user.getUser());
			model.addAttribute("cartList", cartList);
			model.addAttribute("orderList", orderList);
		}

		return "order/orderList";
	}

}
