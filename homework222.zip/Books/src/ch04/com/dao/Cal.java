package ch04.com.dao;

public class Cal {
	
	public int process(int n) {
		return n * n * n;
	}
	
	public int pow(int n) {
		return n * n;
	}
	
}
