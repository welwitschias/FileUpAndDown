package com.baemin.dao;

import java.util.Map;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface AdminMapper {

	//포인트 테이블 내역 insert
	public int pointUpdate(Map<String, Object> ponitUpdateMap);

	//유저 테이블 point update
	public int pointUpdateUser(Map<String, Object> ponitUpdateMap);

}