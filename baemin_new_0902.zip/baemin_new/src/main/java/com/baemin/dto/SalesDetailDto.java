package com.baemin.dto;

import lombok.Data;

@Data
public class SalesDetailDto {
	
	private int totalPrice;
	private String foodInfo;
	
}
