package com.han.delivery;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HandeliveryApplication {

	public static void main(String[] args) {
		SpringApplication.run(HandeliveryApplication.class, args);
	}

}
