package com.baemin.dto;

import java.util.Date;

import lombok.Data;

@Data
public class OrderListDto {
	
	private String orderNum;
	private long storeId;
	private long userId;
	private Date orderDate;
	private String DeliveryStatus;
	private int DeliveryAddress1;
	private String DeliveryAddress2;
	private String DeliveryAddress3;
	private String payMethod;
	private int totalPrice;
	private int usedPoint;
	private String phone;
	private String request;
	private String foodInfo;
	private String storeName;
	private String storeImg;
	private String storeThumb;
	private String deliveryTip;
	private int listCount; // 목록 총 갯수
	
}