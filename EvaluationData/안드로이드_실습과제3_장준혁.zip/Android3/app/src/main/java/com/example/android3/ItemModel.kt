package com.example.android3

data class ItemModel(
    var id: Long = 0,
    var author: String? = "",
    var title: String? = null,
    var description: String? = null,
    var urlToImage: String? = null,
    var publishedAt: String? = ""
)