package com.example.android3

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.android3.databinding.ItemMainBinding

class MyViewHolder(val binding: ItemMainBinding) : RecyclerView.ViewHolder(binding.root)

class MyAdapter(private val context: Context, private val data: MutableList<ItemModel>?) :
    RecyclerView.Adapter<RecyclerView.ViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return MyViewHolder(
            ItemMainBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        )
    }

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val binding = (holder as MyViewHolder).binding
        val model = data!![position]

        binding.itemTitle.text = model.title
        binding.itemDesc.text = model.description
        binding.itemAuthor.text = model.author
        binding.itemTime.text = model.publishedAt

        Glide.with(context)
            .load(model.urlToImage)
            .placeholder(R.drawable.noimage)
            .error(R.drawable.error)
            .into(binding.itemImage)
    }

    override fun getItemCount(): Int {
        return data?.size ?: 0
    }
}