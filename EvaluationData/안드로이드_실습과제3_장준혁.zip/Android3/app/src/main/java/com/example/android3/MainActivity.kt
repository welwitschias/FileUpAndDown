package com.example.android3

import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity
import com.example.android3.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var retrofitFragment: RetrofitFragment

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        retrofitFragment = RetrofitFragment()
        supportFragmentManager.beginTransaction()
            .replace(R.id.activity_content, retrofitFragment)
            .commit()
        supportActionBar?.title = "NEWS"

        binding.goHome.setOnClickListener {
            val bundle = Bundle()
            bundle.putString("category", "null")
            retrofitFragment = RetrofitFragment()
            retrofitFragment.arguments = bundle
            supportFragmentManager.beginTransaction()
                .replace(R.id.activity_content, retrofitFragment)
                .commit()
        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.menu_all -> {
                val bundle = Bundle()
                bundle.putString("category", "null")
                retrofitFragment = RetrofitFragment()
                retrofitFragment.arguments = bundle
                supportFragmentManager.beginTransaction()
                    .replace(R.id.activity_content, retrofitFragment)
                    .commit()
            }
            R.id.menu_home -> {
                val bundle = Bundle()
                bundle.putString("category", "null")
                retrofitFragment = RetrofitFragment()
                retrofitFragment.arguments = bundle
                supportFragmentManager.beginTransaction()
                    .replace(R.id.activity_content, retrofitFragment)
                    .commit()
            }
            R.id.menu_business -> {
                val bundle = Bundle()
                bundle.putString("category", "business")
                retrofitFragment = RetrofitFragment()
                retrofitFragment.arguments = bundle
                supportFragmentManager.beginTransaction()
                    .replace(R.id.activity_content, retrofitFragment)
                    .commit()
            }
            R.id.menu_entertainment -> {
                val bundle = Bundle()
                bundle.putString("category", "entertainment")
                retrofitFragment = RetrofitFragment()
                retrofitFragment.arguments = bundle
                supportFragmentManager.beginTransaction()
                    .replace(R.id.activity_content, retrofitFragment)
                    .commit()
            }
            R.id.menu_sports -> {
                val bundle = Bundle()
                bundle.putString("category", "sports")
                retrofitFragment = RetrofitFragment()
                retrofitFragment.arguments = bundle
                supportFragmentManager.beginTransaction()
                    .replace(R.id.activity_content, retrofitFragment)
                    .commit()
            }
            R.id.menu_health -> {
                val bundle = Bundle()
                bundle.putString("category", "health")
                retrofitFragment = RetrofitFragment()
                retrofitFragment.arguments = bundle
                supportFragmentManager.beginTransaction()
                    .replace(R.id.activity_content, retrofitFragment)
                    .commit()
            }
        }
        return super.onOptionsItemSelected(item)
    }
}