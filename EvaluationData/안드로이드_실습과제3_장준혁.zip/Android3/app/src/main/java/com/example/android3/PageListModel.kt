package com.example.android3

data class PageListModel(
    val articles: MutableList<ItemModel>?
)
