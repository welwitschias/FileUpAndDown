package com.example.android3

import android.app.Application
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class MyApplication : Application() {
    companion object {
        const val API_KEY = "a8f0d4f98b2f4e60847d990ca71a8503"
        private const val BASE_URL = "https://newsapi.org"
        var networkService: NetworkService = retrofit.create(NetworkService::class.java)

        private val retrofit: Retrofit
            get() = Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build()
    }
}