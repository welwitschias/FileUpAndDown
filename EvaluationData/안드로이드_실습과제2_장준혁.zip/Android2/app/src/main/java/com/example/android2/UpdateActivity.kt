package com.example.android2

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.android2.databinding.ActivityUpdateBinding

class UpdateActivity : AppCompatActivity() {
    lateinit var binding: ActivityUpdateBinding
    lateinit var memo: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityUpdateBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val intent = intent
        memo = intent.getStringExtra("memo").toString()
        binding.updateEditView.setText(memo)
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_add, menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.menu_add_save -> {
                val inputData = binding.updateEditView.text.toString()

                if (inputData.isBlank()) {
                    Toast.makeText(this, "내용을 입력해주세요.", Toast.LENGTH_SHORT).show()
                    return false
                } else {
                    val db = DBHelper(this).writableDatabase
                    db.execSQL(
                        "UPDATE memo_table SET memo = ? WHERE memo = ?", arrayOf(inputData, memo)
                    )
                    db.close()

                    val intent = Intent(this, MainActivity::class.java)
                    startActivity(intent)
                }
                true
            }
            else -> true
        }
    }
}