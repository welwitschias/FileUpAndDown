package com.example.android2

import android.app.Activity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.android2.databinding.ActivityAddBinding

class AddActivity : AppCompatActivity() {
    lateinit var binding: ActivityAddBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAddBinding.inflate(layoutInflater)
        setContentView(binding.root)
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_add, menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.menu_add_save -> {
                val intent = intent
                val inputData = binding.addEditView.text.toString()

                if (inputData.isBlank()) {
                    Toast.makeText(this, "내용을 입력해주세요.", Toast.LENGTH_SHORT).show()
                    return false
                } else {
                    val db = DBHelper(this).writableDatabase
                    db.execSQL("INSERT INTO memo_table(memo) VALUES(?)", arrayOf(inputData))
                    db.close()
                    intent.putExtra("memo", inputData)
                    setResult(Activity.RESULT_OK, intent)
                }
                finish()
                true
            }
            else -> true
        }
    }
}